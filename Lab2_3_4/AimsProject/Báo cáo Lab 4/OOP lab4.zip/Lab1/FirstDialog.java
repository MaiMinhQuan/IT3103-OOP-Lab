package Lab1;

//Example 2: FirstDialog.java
import javax.swing.JOptionPane;
public class FirstDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, 
        "Mai Minh Quan - 20225661 - Hello world! How are you?");
        System.exit(0);
    }
}
