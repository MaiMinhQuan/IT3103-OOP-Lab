//Mai Minh Quân - 20225661
//Interface "Playable"

package Lab2_3_4.AimsProject.src.aims.media;
public interface Playable {
    public void play();
}

